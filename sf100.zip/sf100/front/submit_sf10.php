<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert Learner's Information
$last_name = $_POST['last_name'];
$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$lrn = $_POST['lrn'];
$birthdate = $_POST['birthdate'];
$sex = $_POST['sex'];

$sql = "INSERT INTO learners_info (last_name, first_name, middle_name, lrn, birthdate, sex) VALUES ('$last_name', '$first_name', '$middle_name', '$lrn', '$birthdate', '$sex')";
$conn->query($sql);
$learner_id = $conn->insert_id;

// Insert Eligibility Information
$high_school_gen_ave = $_POST['high_school_gen_ave'];
$junior_high_gen_ave = $_POST['junior_high_gen_ave'];
$pept_passer = $_POST['pept_passer'];
$als_passer = $_POST['als_passer'];
$others = $_POST['others'];
$date_completed_jhs = $_POST['date_completed_jhs'];
$date_examination = $_POST['date_examination'];
$schoolname = $_POST['schoolname'];
$schooladd = $_POST['schooladd'];

$sql = "INSERT INTO eligibility (high_school_gen_ave, junior_high_gen_ave, pept_passer, als_passer, others, date_completed_jhs, date_examination, schoolname, schooladd) VALUES ('$high_school_gen_ave', '$junior_high_gen_ave', '$pept_passer', '$als_passer', '$others', '$date_completed_jhs', '$date_examination', '$schoolname', '$schooladd')";
$conn->query($sql);

// Insert Scholastic Record
$school = $_POST['school'];
$school_id = $_POST['school_id'];
$grade_level = $_POST['grade_level'];
$sy = $_POST['sy'];
$sem = $_POST['sem'];
$track_strand = $_POST['track_strand'];
$section = $_POST['section'];
$indicate = $_POST['indicate'];
$Subjects = $_POST['Subjects'];
$semi = $_POST['semi'];
$quarter1 = $_POST['quarter1'];
$quarter2 = $_POST['quarter2'];
$action = $_POST['action'];
$remarks = $_POST['remarks'];
$date_checked = $_POST['date_checked'];

$sql = "INSERT INTO scholastic_records (school, school_id, grade_level, sy, sem, track_strand, section, indicate, Subjects, semi, quarter1, quarter2, action, remarks, date_checked) VALUES ('$school', '$school_id', '$grade_level', '$sy', '$sem', '$track_strand', '$section', '$indicate', '$Subjects', '$semi', '$quarter1', '$quarter2', '$action','$remarks','$date_checked')";
$conn->query($sql);
$scholastic_record_id = $conn->insert_id;

// Insert Remedial Classes
$conducted_from = $_POST['conducted_from'];
$to_date = $_POST['to_date'];
$remschool = $_POST['remschool'];
$remschool_id = $_POST['remschool_id'];
$remtrack_strand = $_POST['remtrack_strand'];
$remsection = $_POST['remsection'];
$remindicate = $_POST['remindicate'];
$remSubjects = $_POST['remSubjects'];
$remquarter1 = $_POST['remquarter1'];
$remquarter2 = $_POST['remquarter2'];
$remsemi = $_POST['remsemi'];
$remaction = $_POST['remaction'];
$remteacher = $_POST['remteacher'];

$sql = "INSERT INTO remedial_classes (conducted_from, to_date, remschool, remschool_id, remtrack_strand, remsection, remindicate, remSubjects, remquarter1, remquarter2, remsemi, remaction, remteacher)
 VALUES ('$conducted_from', '$to_date', '$remschool', '$remschool_id', '$remtrack_strand', '$remsection', '$remindicate', '$remSubjects', '$remquarter1', '$remquarter2', '$remsemi', '$remaction', '$remteacher')";
$conn->query($sql);
$remedial_class_id = $conn->insert_id;



// Close the connection
$conn->close();

// Redirect to print_output.php
header("Location: print_output.php");
exit();
?>
