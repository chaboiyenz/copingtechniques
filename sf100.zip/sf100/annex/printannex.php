<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="navbar">
    <div>
        <img src="logo.png" alt="Logo" class="logo">
    </div>
    <div class="nav-links">
        <a href="#"></a>
    </div>
</div>


<div class="result">



<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM MyGuests WHERE id=3";

$sql = "SELECT * FROM annex";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo  "CORE SUBJECTS:" . $row["oral_communication"]."<br>" 
    ."" .$row["reading_writing"] ."<br>" 
    ."" .$row["komunikasyon"] ."<br>" 
    ."" .$row["pagbasa"] ."<br>" 
    ."" .$row["literature"] ."<br>" 
    ."" .$row["arts"] ."<br>"
    ."" .$row["media"] ."<br>" 
    ."" .$row["math"] ."<br>" 
    ."" .$row["statistics"] ."<br>" 
    ."" .$row["earth_life"] ."<br>" 
    ."" .$row["physical_science"] ."<br>"
    ."" .$row["personal_development"] ."<br>" 
    ."" .$row["culture"] ."<br>" 
    ."" .$row["philosophy"] ."<br>" 
    ."" .$row["pe_health"] ."<br>" 
    ."" .$row["earth_science"] ."<br>"
    ."" .$row["disaster"] ."<br>" 
    ."" .$row["remarks_core"] ."<br>" 
    ."APPLIED SUBJECTS:" .$row["eapp"] ."<br>" 
    ."" .$row["pr1"] ."<br>" 
    ."" .$row["pr2"] ."<br>" 
    ."" .$row["filipino"] ."<br>"
    ."".$row["empowerment_tech"] ."<br>" 
    ."" .$row["entrepreneurship"] ."<br>" 
    ."" .$row["iii"] ."<br>" 
    ."SPECIALIZED SUBJECTS:" .$row["remarks_specialized"] ."<br>" 
    ."OTHER SUBJECTS:" .$row["remarks_others"] ."<br>";

  }
}

else {
  echo "0 results";
}

$conn->close();
?>
</div>