document.getElementById('addRow').addEventListener('click', function() {
    var tableBody = document.querySelector('.table-container tbody');
    var newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td><input type="text" name="selection[]" required></td>
        <td><input type="text" name="subjects[]" required></td>
        <td><input type="text" name="quarter1[]" required></td>
        <td><input type="text" name="quarter2[]" required></td>
        <td><input type="text" name="final_grade[]" required></td>
        <td><input type="text" name="action_taken[]" required></td>
        <td><input type="checkbox" name="select[]"></td>
    `;
    tableBody.appendChild(newRow);
});

document.getElementById('performAction').addEventListener('click', function() {
    var checkboxes = document.querySelectorAll('.table-container tbody input[type="checkbox"]');
    checkboxes.forEach(function(checkbox) {
        if (checkbox.checked) {
            checkbox.parentElement.parentElement.remove();
        }
    });
});

document.getElementById('high_school_checkbox').addEventListener('change', function() {
    var highSchoolCheckbox = document.getElementById('high_school_checkbox');
    var juniorHighGenAve = document.getElementById('junior_high_gen_ave');
    var juniorHighCheckbox = document.getElementById('junior_high_checkbox');
    if (highSchoolCheckbox.checked) {
        juniorHighGenAve.disabled = true;
        juniorHighCheckbox.disabled = true;
    } else {
        juniorHighGenAve.disabled = false;
        juniorHighCheckbox.disabled = false;
    }
});

document.getElementById('junior_high_checkbox').addEventListener('change', function() {
    var juniorHighCheckbox = document.getElementById('junior_high_checkbox');
    var highSchoolGenAve = document.getElementById('high_school_gen_ave');
    var highSchoolCheckbox = document.getElementById('high_school_checkbox');
    if (juniorHighCheckbox.checked) {
        highSchoolGenAve.disabled = true;
        highSchoolCheckbox.disabled = true;
    } else {
        highSchoolGenAve.disabled = false;
        highSchoolCheckbox.disabled = false;
    }
});

document.getElementById('others_checkbox').addEventListener('change', function() {
    document.getElementById('others_specify').style.display = this.checked ? 'block' : 'none';
});
