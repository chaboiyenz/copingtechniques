<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$oral_communication = $_POST['oral_communication'];
$reading_writing = $_POST['reading_writing'];
$komunikasyon = $_POST['komunikasyon'];
$pagbasa = $_POST['pagbasa'];
$literature = $_POST['literature'];
$arts = $_POST['arts'];
$media = $_POST['media'];
$math = $_POST['math'];
$statistics = $_POST['statistics'];
$earth_life = $_POST['earth_life'];
$physical_science = $_POST['physical_science'];
$personal_development = $_POST['personal_development'];
$culture = $_POST['culture'];
$philosophy = $_POST['philosophy'];
$pe_health = $_POST['pe_health'];
$earth_science = $_POST['earth_science'];
$disaster = $_POST['disaster'];
$remarks_core = $_POST['remarks_core'];
$eapp = $_POST['eapp'];
$pr1 = $_POST['pr1'];
$pr2 = $_POST['pr2'];
$filipino = $_POST['filipino'];
$empowerment_tech = $_POST['empowerment_tech'];
$entrepreneurship = $_POST['entrepreneurship'];
$iii = $_POST['iii'];
$remarks_specialized = $_POST['remarks_specialized'];
$remarks_others = $_POST['remarks_others'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO annex (oral_communication, reading_writing, komunikasyon, pagbasa, literature, arts, media, math, statistics, earth_life, physical_science, personal_development, culture, philosophy, pe_health, earth_science, disaster, remarks_core, eapp, pr1, pr2, filipino, empowerment_tech, entrepreneurship, iii, remarks_specialized, remarks_others) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("sssssssssssssssssssssssssss", 
    $oral_communication, 
    $reading_writing, 
    $komunikasyon, 
    $pagbasa, 
    $literature, 
    $arts, 
    $media, 
    $math, 
    $statistics, 
    $earth_life, 
    $physical_science, 
    $personal_development, 
    $culture, 
    $philosophy, 
    $pe_health, 
    $earth_science, 
    $disaster, 
    $remarks_core, 
    $eapp, 
    $pr1, 
    $pr2, 
    $filipino, 
    $empowerment_tech, 
    $entrepreneurship, 
    $iii, 
    $remarks_specialized, 
    $remarks_others);

    if ($stmt->execute()) {
        header("Location: printannex.php"); 
    } else {
        echo "Error: " . $stmt->error;
    }
    
// Close the statement and connection
$stmt->close();
$conn->close();
?>
