<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ANNEX</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" type="text/css" href="printannex.css" media="print">

</head>
<body>
<div class="navbar">
    <div>
        <img src="logo.png" alt="Logo" class="logo">
    </div>
    
</div>
<br>
<br>
    
<br>
<br>
<br>
<br>

<script type="text/javascript">
        function navigateToSubmit_sf102Page() {
            alert("Are you sure you want to submit?");
        }

        function handleSubmit(event) {
            navigateToSubmit_sf102Page();
        }
    </script>

<script type="text/javascript">
        function navigateToResultPage() {
            alert("Are you sure you want to submit?");
        }

        function handleSubmit(event) {
            navigateToResultPage();
        }
    </script>


<form action="submit_sf102.php" method="post" onsubmit="handleSubmit()">
    <h2>Senior High School Student Permanent Record</h2>
    <h3>ANNEX: LIST OF SUBJECTS TAKEN</h3>

    <section class="learner-info highlight">
        <h3>Core Subjects</h3>
        <div class="container">
            <div>

                <input type="hidden" id="oral_communication" name="oral_communication" value=" "> </label>
                <label><input type="checkbox" id="oral_communication" name="oral_communication" value="Oral Communication"> Oral Communication</label>
        
                <input type="hidden" id="reading_writing" name="reading_writing" value=" "> </label>
                <label><input type="checkbox" id="reading_writing" name="reading_writing" value="Reading and Writing"> Reading and Writing</label>
                
                <input type="hidden" id="komunikasyon" name="komunikasyon" value=" "> </label>
                <label><input type="checkbox" id="komunikasyon" name="komunikasyon" value="Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino"> Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino</label>
                
                <input type="hidden" id="pagbasa" name="pagbasa" value=" "> </label>
                <label><input type="checkbox" id="pagbasa" name="pagbasa" value="Pagbasa at Pagsusuri ng iba't ibang Teksto Tungo sa Pananaliksik"> Pagbasa at Pagsusuri ng iba't ibang Teksto Tungo sa Pananaliksik</label>
                
                <input type="hidden" id="literature" name="literature" value=" "> </label>
                <label><input type="checkbox" id="literature" name="literature" value="21st Century Literature from the Philippines and the World"> 21st Century Literature from the Philippines and the World</label>
                
                <input type="hidden" id="arts" name="arts" value=" "> </label>
                <label><input type="checkbox" id="arts" name="arts" value="Contemporary Philippine Arts from the Regions"> Contemporary Philippine Arts from the Regions</label>
                
                <input type="hidden" id="media" name="media" value=" "> </label>
                <label><input type="checkbox" id="media" name="media" value="Media and Information Literacy"> Media and Information Literacy</label>
                
                <input type="hidden" id="math" name="math" value=" "> </label>
                <label><input type="checkbox" id="math" name="math" value="General Mathematics"> General Mathematics</label>
                
                <input type="hidden" id="statistics" name="statistics" value=" "> </label>
                <label><input type="checkbox" id="statistics" name="statistics" value="Statistics and Probability"> Statistics and Probability</label>
                
                <input type="hidden" id="earth_life" name="earth_life" value=" "> </label>
                <label><input type="checkbox" id="earth_life" name="earth_life" value="Earth and Life Science"> Earth and Life Science</label>
                
                <input type="hidden" id="physical_science" name="physical_science" value=" "> </label>
                <label><input type="checkbox" id="physical_science" name="physical_science" value="Physical Science"> Physical Science</label>
                
                <input type="hidden" id="personal_development" name="personal_development" value=" "> </label>
                <label><input type="checkbox" id="personal_development" name="personal_development" value="Personal Development/Pansariling Kaunlaran"> Personal Development/Pansariling Kaunlaran</label>
                
                <input type="hidden" id="culture" name="culture" value=" "> </label>
                <label><input type="checkbox" id="culture" name="culture" value="Understanding Culture, Society and Politics"> Understanding Culture, Society and Politics</label>
                
                <input type="hidden" id="philosophy" name="philosophy" value=" "> </label>
                <label><input type="checkbox" id="philosophy" name="philosophy" value="Introduction to the Philosophy of the Human Person/Pambungad sa Pilosopiya ng Tao"> Introduction to the Philosophy of the Human Person/Pambungad sa Pilosopiya ng Tao</label>
                
                <input type="hidden" id="pe_health" name="pe_health" value=" "> </label>
                <label><input type="checkbox" id="pe_health" name="pe_health" value="Physical Education and Health"> Physical Education and Health</label>
            </div>
            
            <div>
                <label>STEM students will take these instead:</label>
                
                <input type="hidden" id="earth_science" name="earth_science" value=" "> </label>
                <label><input type="checkbox" id="earth_science" name="earth_science" value="Earth Science"> Earth Science</label>
                
                <input type="hidden" id="disaster" name="disaster" value=" "> </label>
                <label><input type="checkbox" id="disaster" name="disaster" value="Disaster Readiness and Risk Reduction"> Disaster Readiness and Risk Reduction</label>
                <h3>Subject Subtitutions. if any</h3>
               
                <input type="hidden" id="remarks_core" name="remarks_core" value=" "> </label>
                <textarea name="remarks_core" rows="4" cols="50"></textarea>
            </div>
        </div>
    </section>
    <br>


    <section class="eligibility highlight">
        <h3>Applied Subjects</h3>
        <div class="container">
            
        <input type="hidden" id="eapp" name="eapp" value=" ">
        <label><input type="checkbox" id="eapp" name="eapp" value="English for Academic and Professional Purposes"> English for Academic and Professional Purposes</label>
            
        <input type="hidden" id="pr1" name="pr1" value=" ">
        <label><input type="checkbox" id="pr1" name="pr1" value="Practical Research 1"> Practical Research 1</label>
           
        <input type="hidden" id="pr2" name="pr2" value=" ">
        <label><input type="checkbox" id="pr2" name="pr2" value="Practical Research 2"> Practical Research 2</label>
           
        <input type="hidden" id="filipino" name="filipino" value=" ">
        <label><input type="checkbox" id="filipino" name="filipino" value="Filipino sa Piling Larangan"> Filipino sa Piling Larangan</label>
            
        <input type="hidden" id="empowerment_tech" name="empowerment_tech" value=" ">
        <label><input type="checkbox" id="empowerment_tech" name="empowerment_tech" value="Empowerment Technologies"> Empowerment Technologies</label>
            
        <input type="hidden" id="entrepreneurship" name="entrepreneurship" value=" ">
        <label><input type="checkbox" id="entrepreneurship" name="entrepreneurship" value="Entrepreneurship"> Entrepreneurship</label>
            
        <input type="hidden" id="iii" name="iii" value=" ">
        <label><input type="checkbox" id="iii" name="iii" value="Inquiries, Investigation and Immersion"> Inquiries, Investigation and Immersion</label>
        </div>
    </section>
    <br>

    <section class="remarks">
        <h3>Specialized Subjects (Please Write the List Below)</h3>
        
        <input type="hidden" id="remarks_specialized" name="remarks_specialized" value=" ">
        <textarea name="remarks_specialized" rows="4" cols="50"></textarea>
    </section>
    <br>

    <section class="remarks">
        <h3>Other Subjects (Please Write the List Below)</h3>
        <input type="hidden" id="remarks_others" name="remarks_others" value=" ">
        <textarea name="remarks_others" rows="4" cols="50"></textarea>
    </section>

  
    <script type="text/javascript">
        function redirectToPage() {
            window.location.href = "result.php";
        }
    </script>
    
    <section class="bottom-container">
    <button type="submit" value="Save Record">SAVE RECORD</button>
<br>
        <button type="button" onclick="history.back(); return false;">Go Back</a></button>
        <br>
        <CENTER> <button type="button" onclick="redirectToPage()"> <h1> SUBMIT <h1> </button> </CENTER>

    </section>

</form>

<script src="scripts.js"></script>
</body>
</html>


