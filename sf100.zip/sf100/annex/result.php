<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
</head>

<div class="result">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, first_name, last_name, middle_name, lrn, birthdate, sex FROM learners_info";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo  "First Name: " . $row["first_name"]."<br>" 
    ."Last Name: " .$row["last_name"] ."<br>" 
    ."Middle Name: " .$row["middle_name"] ."<br>" 
    ."LRN: " .$row["lrn"] ."<br>" 
    ."Birthday: " .$row["birthdate"] ."<br>" 
    ."Sex: " .$row["sex"] ."<br>";
  }
}

$sql = "SELECT * FROM eligibility";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

echo "High School General Average: " .$row["high_school_gen_ave"] ."<br>"
."Junior High General Average: " .$row["junior_high_gen_ave"] ."<br>"
."PEPT Passer: " .$row["pept_passer"] ."<br>"
."ALS Passer: " .$row["als_passer"] ."<br>"
."Others: " .$row["others"] ."<br>"
."Date Completed (Junior High School): " .$row["date_completed_jhs"] ."<br>"
."Date Examination: " .$row["date_examination"] ."<br>"
."School Name: " .$row["schoolname"] ."<br>"
."School Address: " .$row["schooladd"] ."<br>";
}
} 

$sql = "SELECT * FROM scholastic_records";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

echo "<br>" ."SCHOLASTIC RECORD" ."<br>" ."<br>"
."SCHOOL: " .$row["school"] ."<br>"
."SCHOOL ID: " .$row["school_id"] ."<br>"
."GRADE LEVEL: " .$row["grade_level"] ."<br>"
."SCHOOL YEAR: " .$row["sy"] ."<br>"
."SEM: " .$row["sem"] ."<br>"
."TRACK/STRAND: " .$row["track_strand"] ."<br>"
."SECTION: " .$row["section"] ."<br>"
."INDICATION: " .$row["indicate"] ."<br>"
."SUBJECTS: " .$row["Subjects"] ."<br>"
."SEMI FINAL GRADE: " .$row["semi"] ."<br>"
."REMEDIAL CLASS MARK: " .$row["quarter1"] ."<br>"
."RECOMPUTED FINAL GRADE: " .$row["quarter2"] ."<br>"
."ACTION TAKEN " .$row["action"] ."<br>"
."REMARS: " .$row["remarks"] ."<br>"
."DATE CHECKED: " .$row["date_checked"] ."<br>";

}
} 

$sql = "SELECT * FROM remedial_classes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

echo "<br>" ."REMEDIAL CLASSES CONDUCTED FROM: " .$row["conducted_from"] ."<br>"
."TO: " .$row["to_date"] ."<br>"
."SCHOOL: " .$row["remschool"] ."<br>"
."SCHOOL ID: " .$row["remschool_id"] ."<br>"
."TRACK/STRAND: " .$row["remtrack_strand"] ."<br>"
."SECTION: " .$row["remsection"] ."<br>"
."Indication: " .$row["remindicate"] ."<br>"
."Subjects: " .$row["remSubjects"] ."<br>"
."Quarter1: " .$row["remquarter1"] ."<br>"
."Quarter2: " .$row["remquarter2"] ."<br>"
."Semi Final Grade: " .$row["remsemi"] ."<br>"
."Action: " .$row["remaction"] ."<br>"
."Teacher's Name: " .$row["remteacher"] ."<br>";
}
} 


$sql = "SELECT * FROM scholastic_records";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

echo "<br>" ."SCHOLASTIC RECORD" ."<br>" ."<br>"
."SCHOOL: " .$row["school"] ."<br>"
."SCHOOL ID: " .$row["school_id"] ."<br>"
."GRADE LEVEL: " .$row["grade_level"] ."<br>"
."SCHOOL YEAR: " .$row["sy"] ."<br>"
."SEM: " .$row["sem"] ."<br>"
."TRACK/STRAND: " .$row["track_strand"] ."<br>"
."SECTION: " .$row["section"] ."<br>"
."INDICATION: " .$row["indicate"] ."<br>"
."SUBJECTS: " .$row["Subjects"] ."<br>"
."SEMI FINAL GRADE: " .$row["semi"] ."<br>"
."REMEDIAL CLASS MARK: " .$row["quarter1"] ."<br>"
."RECOMPUTED FINAL GRADE: " .$row["quarter2"] ."<br>"
."ACTION TAKEN " .$row["action"] ."<br>"
."REMARS: " .$row["remarks"] ."<br>"
."DATE CHECKED: " .$row["date_checked"] ."<br>";

}
} 

$sql = "SELECT * FROM remedial_classes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

echo "<br>" ."REMEDIAL CLASSES CONDUCTED FROM: " .$row["conducted_from"] ."<br>"
."TO: " .$row["to_date"] ."<br>"
."SCHOOL: " .$row["remschool"] ."<br>"
."SCHOOL ID: " .$row["remschool_id"] ."<br>"
."TRACK/STRAND: " .$row["remtrack_strand"] ."<br>"
."SECTION: " .$row["remsection"] ."<br>"
."Indication: " .$row["remindicate"] ."<br>"
."Subjects: " .$row["remSubjects"] ."<br>"
."Quarter1: " .$row["remquarter1"] ."<br>"
."Quarter2: " .$row["remquarter2"] ."<br>"
."Semi Final Grade: " .$row["remsemi"] ."<br>"
."Action: " .$row["remaction"] ."<br>"
."Teacher's Name: " .$row["remteacher"] ."<br>";
}
} 

$sql = "SELECT * FROM scholastic_records";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

echo "<br>" ."SCHOLASTIC RECORD" ."<br>" ."<br>"
."SCHOOL: " .$row["school"] ."<br>"
."SCHOOL ID: " .$row["school_id"] ."<br>"
."GRADE LEVEL: " .$row["grade_level"] ."<br>"
."SCHOOL YEAR: " .$row["sy"] ."<br>"
."SEM: " .$row["sem"] ."<br>"
."TRACK/STRAND: " .$row["track_strand"] ."<br>"
."SECTION: " .$row["section"] ."<br>"
."INDICATION: " .$row["indicate"] ."<br>"
."SUBJECTS: " .$row["Subjects"] ."<br>"
."SEMI FINAL GRADE: " .$row["semi"] ."<br>"
."REMEDIAL CLASS MARK: " .$row["quarter1"] ."<br>"
."RECOMPUTED FINAL GRADE: " .$row["quarter2"] ."<br>"
."ACTION TAKEN " .$row["action"] ."<br>"
."REMARS: " .$row["remarks"] ."<br>"
."DATE CHECKED: " .$row["date_checked"] ."<br>";

}
} 

$sql = "SELECT * FROM remedial_classes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

echo "<br>" ."REMEDIAL CLASSES CONDUCTED FROM: " .$row["conducted_from"] ."<br>"
."TO: " .$row["to_date"] ."<br>"
."SCHOOL: " .$row["remschool"] ."<br>"
."SCHOOL ID: " .$row["remschool_id"] ."<br>"
."TRACK/STRAND: " .$row["remtrack_strand"] ."<br>"
."SECTION: " .$row["remsection"] ."<br>"
."Indication: " .$row["remindicate"] ."<br>"
."Subjects: " .$row["remSubjects"] ."<br>"
."Quarter1: " .$row["remquarter1"] ."<br>"
."Quarter2: " .$row["remquarter2"] ."<br>"
."Semi Final Grade: " .$row["remsemi"] ."<br>"
."Action: " .$row["remaction"] ."<br>"
."Teacher's Name: " .$row["remteacher"] ."<br>";
}
} 


$sql = "SELECT * FROM scholastic_records";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

echo "<br>" ."SCHOLASTIC RECORD" ."<br>" ."<br>"
."SCHOOL: " .$row["school"] ."<br>"
."SCHOOL ID: " .$row["school_id"] ."<br>"
."GRADE LEVEL: " .$row["grade_level"] ."<br>"
."SCHOOL YEAR: " .$row["sy"] ."<br>"
."SEM: " .$row["sem"] ."<br>"
."TRACK/STRAND: " .$row["track_strand"] ."<br>"
."SECTION: " .$row["section"] ."<br>"
."INDICATION: " .$row["indicate"] ."<br>"
."SUBJECTS: " .$row["Subjects"] ."<br>"
."SEMI FINAL GRADE: " .$row["semi"] ."<br>"
."REMEDIAL CLASS MARK: " .$row["quarter1"] ."<br>"
."RECOMPUTED FINAL GRADE: " .$row["quarter2"] ."<br>"
."ACTION TAKEN " .$row["action"] ."<br>"
."REMARS: " .$row["remarks"] ."<br>"
."DATE CHECKED: " .$row["date_checked"] ."<br>";

}
} 

$sql = "SELECT * FROM remedial_classes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

echo "<br>" ."REMEDIAL CLASSES CONDUCTED FROM: " .$row["conducted_from"] ."<br>"
."TO: " .$row["to_date"] ."<br>"
."SCHOOL: " .$row["remschool"] ."<br>"
."SCHOOL ID: " .$row["remschool_id"] ."<br>"
."TRACK/STRAND: " .$row["remtrack_strand"] ."<br>"
."SECTION: " .$row["remsection"] ."<br>"
."Indication: " .$row["remindicate"] ."<br>"
."Subjects: " .$row["remSubjects"] ."<br>"
."Quarter1: " .$row["remquarter1"] ."<br>"
."Quarter2: " .$row["remquarter2"] ."<br>"
."Semi Final Grade: " .$row["remsemi"] ."<br>"
."Action: " .$row["remaction"] ."<br>"
."Teacher's Name: " .$row["remteacher"] ."<br>";
}
} 


$sql = "DELETE FROM MyGuests WHERE id=3";

$sql = "SELECT * FROM annex";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
echo  "CORE SUBJECTS:" . $row["oral_communication"]."<br>" 
."" .$row["reading_writing"] ."<br>" 
."" .$row["komunikasyon"] ."<br>" 
."" .$row["pagbasa"] ."<br>" 
."" .$row["literature"] ."<br>" 
."" .$row["arts"] ."<br>"
."" .$row["media"] ."<br>" 
."" .$row["math"] ."<br>" 
."" .$row["statistics"] ."<br>" 
."" .$row["earth_life"] ."<br>" 
."" .$row["physical_science"] ."<br>"
."" .$row["personal_development"] ."<br>" 
."" .$row["culture"] ."<br>" 
."" .$row["philosophy"] ."<br>" 
."" .$row["pe_health"] ."<br>" 
."" .$row["earth_science"] ."<br>"
."" .$row["disaster"] ."<br>" 
."" .$row["remarks_core"] ."<br>" 
."APPLIED SUBJECTS:" .$row["eapp"] ."<br>" 
."" .$row["pr1"] ."<br>" 
."" .$row["pr2"] ."<br>" 
."" .$row["filipino"] ."<br>"
."".$row["empowerment_tech"] ."<br>" 
."" .$row["entrepreneurship"] ."<br>" 
."" .$row["iii"] ."<br>" 
."SPECIALIZED SUBJECTS:" .$row["remarks_specialized"] ."<br>" 
."OTHER SUBJECTS:" .$row["remarks_others"] ."<br>";
}
}

else {
echo "0 results";
}


$conn->close();
?>

</div>