function addRow(tableId) {
    const table = document.getElementById(tableId).getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();

    // Define the cells to be added dynamically
    const cells = [
        "Indicate if Subject is CORE, APPLIED, or SPECIALIZED",
        "Subjects",
        "Quarter 1",
        "Quarter 2",
        "SEMI FINAL GRADE",
        "ACTION TAKEN"
    ];

    cells.forEach((cell, index) => {
        const newCell = newRow.insertCell();
        const input = document.createElement("input");
        input.type = "text";
        input.name = cell.toLowerCase().replace(/ /g, "_");
        if (index >= 2 && index <= 3) {
            input.oninput = calculateGrade; // Bind calculateGrade function for grade calculation
        }
        newCell.appendChild(input);
    });

    // Add delete button
    const actionCell = newRow.insertCell();
    actionCell.classList.add('center');
    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.innerText = "Delete";
    deleteButton.onclick = () => table.deleteRow(newRow.rowIndex);
    actionCell.appendChild(deleteButton);
}

function addRemedialRow() {
    const table = document.getElementById('remedialClasses').getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();

    const cells = [
        "Indicate if Subject is CORE, APPLIED, or SPECIALIZED",
        "Subjects",
        "Semi Final Grade",
        "Remedial Class Mark",
        "Recomputed Final Grade",
        "ACTION TAKEN"
    ];

    function addRemedialRow1() {
        const table = document.getElementById('remedialClasses1').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();
    
        const cells = [
            "Indicate if Subject is CORE, APPLIED, or SPECIALIZED",
            "Subjects",
            "Semi Final Grade",
            "Remedial Class Mark",
            "Recomputed Final Grade",
            "ACTION TAKEN"
        ];
    }

    cells.forEach(cell => {
        const newCell = newRow.insertCell();
        const input = document.createElement("input");
        input.type = "text";
        input.name = cell.toLowerCase().replace(/ /g, "_");
        newCell.appendChild(input);
    });

    // Add delete button
    const actionCell = newRow.insertCell();
    actionCell.classList.add('center');
    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.innerText = "Delete";
    deleteButton.onclick = () => table.deleteRow(newRow.rowIndex);
    actionCell.appendChild(deleteButton);
}

function signAdviser() {
    const adviserName = prompt("Please enter the name of the Adviser:");
    if (adviserName) {
        const adviserButton = document.querySelector('.signature-container .signature button');
        adviserButton.innerText = adviserName;
        adviserButton.style.borderBottom = '1px solid #000';
    }
}

function signAuthorized() {
    const authorizedName = prompt("Please enter the name of the Authorized Person:");
    if (authorizedName) {
        const authorizedButton = document.querySelector('.signature-container .signature:last-child button');
        authorizedButton.innerText = authorizedName;
        authorizedButton.style.borderBottom = '1px solid #000';
    }
}
    // Function to capture and display teacher's signature
    function signTeacher() {
    const teacherName = document.getElementById('teacher_name').value;
    if (teacherName) {
        const teacherButton = document.querySelector('.signature-container .signature:last-child button');
        teacherButton.innerText = teacherName;
        teacherButton.style.borderBottom = '1px solid #000';
    }
}
function navigateToAnnexPage() {
    window.location.href = '../annex/index.php';
}