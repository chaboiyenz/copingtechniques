<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <div>
        <img src="logo.png" alt="Logo" class="logo">
    </div>
</div>

<br><br>
<br>
<br>
<br>


<script type="text/javascript">
        function navigateToSubmit_sf101Page() {
            alert("Are you sure you want to submit?");
        }

        function handleSubmit(event) {
            navigateToSubmit_sf101Page();
        }
    </script>

<form action="submit_sf101.php" method="post" onsubmit="handleSubmit()">
<table>


    <h2>Scholastic Record</h2>
            <tr>
                <td>SCHOOL: <input type="text" name="school"></td>
                <td>SCHOOL ID: <input type="text" name="school_id"></td>
                <td>GRADE LEVEL: <input type="text" name="grade_level"></td>
                <td>SY: <input type="text" name="sy"></td>
                <td>SEM: <input type="text" name="sem"></td>
            </tr>
            <tr>
                <td colspan="5">TRACK/STRAND: <input type="text" name="track_strand"></td>
            </tr>
            <tr>
                <td colspan="5">SECTION: <input type="text" name="section"></td>
            </tr>
        </table>
        <table id="scholasticTable">
            <thead>
                <tr>
                    <label for="indicate"> <th>Indicate if Subject is CO    RE, APPLIED, or SPECIALIZED <select id="text" name="indicate">  </label>
                    <option></option>
                    <option value="CORE">CORE</option>
                    <option value="APPLIED">APPLIED</option>
                    <option value="SPECIALIZED">SPECIALIZED</option>
                    </th>
                    <th> Subjects <input type="text" name="Subjects"></th>
                    <th> SEMI FINAL GRADE <input type="text" name="semi"> </th>
                    <th> REMEDIAL CLASS MARK <input type="text" name="quarter1"></th>
                    <th> RECOMPUTED FINAL GRADE <input type="text" name="quarter2"></th>
                    <th> ACTION TAKEN <input type="text" name="action"> </th>
                </tr>
            </thead>
        </table>
        <button type="button" class="button" onclick="addRow('scholasticTable')">Add Row</button>




        <section class="remarks">
        <h3>Remarks</h3>
        <textarea name="remarks" rows="4" cols="50"></textarea>
    </section>

    <section class="certification">
        <p><b>Certified True and Correct</b></p>
        <p>Date Checked (MM/DD/YYYY): <input type="date" name="date_checked" ></p>
        <div class="signature-container">
            <div class="signature">
                <button type="button" onclick="signAdviser()">_______________________________</button>
                <p>Signature of Adviser over Printed Name</p>
            </div>
            <div class="signature">
                <button type="button" onclick="signAuthorized()">_______________________________</button>
                <p>Signature of Authorized Person over Printed Name, Designation</p>
            </div>
        </div>
    </section>
    
  
    
    <br><br>
    


    <table>
    <h2>Remedial Classes</h2>

            <tr>
                <td>REMEDIAL CLASSES CONDUCTED FROM:<input type="date" name="conducted_from"></td>
                <td>TO:<input type="date" name="to_date"></td>
                <td>SCHOOL: <input type="text" name="remschool" ></td>
                <td>SCHOOL ID: <input type="text" name="remschool_id" ></td>
            </tr>
            <tr>
                <td colspan="5">TRACK/STRAND: <input type="text" name="remtrack_strand" ></td>
            </tr>
            <tr>
                <td colspan="5">SECTION: <input type="text" name="remsection" ></td>
            </tr>
        </table>
        <table id="remedialClasses">
            <thead>
                <<tr>
                    <label for="indicate"> <th>Indicate if Subject is CORE, APPLIED, or SPECIALIZED <select id="text" name="remindicate">  </label>
                    <option></option>

                    <option value="CORE">CORE</option>
                    <option value="APPLIED">APPLIED</option>
                    <option value="SPECIALIZED">SPECIALIZED</option>
                    </th>
                    <th> Subjects <input type="text" name="remSubjects"></th>
                    <th> Quarter 1 <input type="text" name="remquarter1"></th>
                    <th> Quarter 2 <input type="text" name="remquarter2"></th>
                    <th> SEMI FINAL GRADE <input type="text" name="remsemi"> </th>
                    <th> ACTION TAKEN <input type="text" name="remaction"> </th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <button type="button" class="button" onclick="addRemedialRow()">Add Row</button>
 
  
        
        <section class="certification">
        <div class="signature">
            <input type="text" id="remteacher" name="remteacher" placeholder="Enter Teacher's Name">
            <label for="teacher_signature">Teacher's Signature:</label>
            <button type="button" onclick="signTeacher()">_______________________________</button>
        </div>
    </div>
</section>

<BR> <BR>

    <table>
    <h2>Scholastic Record</h2>

            <tr>
                <td>SCHOOL: <input type="text" name="schoolhaha"></td>
                <td>SCHOOL ID: <input type="text" name="school_idschoolhaha"></td>
                <td>GRADE LEVEL: <input type="text" name="grade_levelschoolhaha"></td>
                <td>SY: <input type="text" name="syschoolhaha"></td>
                <td>SEM: <input type="text" name="semschoolhaha"></td>
            </tr>
            <tr>
                <td colspan="5">TRACK/STRAND: <input type="text" name="track_strandschoolhaha"></td>
            </tr>
            <tr>
                <td colspan="5">SECTION: <input type="text" name="sectionschoolhaha"></td>
            </tr>
        </table>
        <table id="scholasticTable">
            <thead>
            <tr>
                    <label for="indicate"> <th>Indicate if Subject is CORE, APPLIED, or SPECIALIZED <select id="text" name="indicatschoolhahae">  </label>
                    <option></option>
                    <option value="CORE">CORE</option>
                    <option value="APPLIED">APPLIED</option>
                    <option value="SPECIALIZED">SPECIALIZED</option>
                    </th>
                    <th> Subjects <input type="text" name="Subjeschoolhahacts"></th>
                    <th> SEMI FINAL GRADE <input type="text" name="semschoolhahai"> </th>
                    <th> REMEDIAL CLASS MARK <input type="text" name="quaschoolhaharter1"></th>
                    <th> RECOMPUTED FINAL GRADE <input type="text" name="quarschoolhahater2"></th>
                    <th> ACTION TAKEN <input type="text" name="actschoolhahaion"> </th>
                </tr>
            </thead>
        </table>
        <button type="button" class="button" onclick="addRow('scholasticTable')">Add Row</button>

        <section class="remarks">
        <h3>Remarks</h3>
        <textarea name="reschoolhahamarks" rows="4" cols="50"></textarea>
    </section>

    <section class="certification">
        <p><b>Certified True and Correct</b></p>
        <p>Date Checked (MM/DD/YYYY): <input type="date" name="date_schoolhahachecked" ></p>
        <div class="signature-container">
            <div class="signature">
                <button type="button" onclick="signAdviser()">_______________________________</button>
                <p>Signature of Adviser over Printed Name</p>
            </div>
            <div class="signature">
                <button type="button" onclick="signAuthorized()">_______________________________</button>
                <p>Signature of Authorized Person over Printed Name, Designation</p>
            </div>
        </div>
    </section>
  
    <br><br>

    <table>
    <h2>Remedial Classes</h2>

            <tr>
                <td>REMEDIAL CLASSES CONDUCTED FROM:<input type="date" name="conducted_schoolhahafrom"></td>
                <td>TO:<input type="date" name="to_dschoolhahaate"></td>
                <td>SCHOOL: <input type="text" name="schschoolhahaool" ></td>
                <td>SCHOOL ID: <input type="text" name="schschoolhahaool_id" ></td>
            </tr>
            <tr>
                <td colspan="5">TRACK/STRAND: <input type="text" name="tracschoolhahak_strand" ></td>
            </tr>
            <tr>
                <td colspan="5">SECTION: <input type="text" name="seschoolhahaction" ></td>
            </tr>
        </table>
        <table id="remedialClasses">
            <thead>
                <<tr>
                    <label for="indicate"> <th>Indicate if Subject is CORE, APPLIED, or SPECIALIZED <select id="text" name="indicate">  </label>
                    <option></option>

                    <option value="CORE">CORE</option>
                    <option value="APPLIED">APPLIED</option>
                    <option value="SPECIALIZED">SPECIALIZED</option>
                    </th>
                    <th> Subjects <input type="text" name="Suschoolhahabjects"></th>
                    <th> Quarter 1 <input type="text" name="quaschoolhaharter1"></th>
                    <th> Quarter 2 <input type="text" name="quarschoolhahater2"></th>
                    <th> SEMI FINAL GRADE <input type="text" name="seschoolhahami"> </th>
                    <th> ACTION TAKEN <input type="text" name="actioschoolhahan"> </th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <button type="button" class="button" onclick="addRemedialRow()">Add Row</button>
  
        
        <section class="certification">
        <div class="signature">
            <input type="text" id="teachschoolhahaer_name" name="teaschoolhahacher_name" placeholder="Enter Teacher's Name">
            <label for="teacher_signature">Teacher's Signature:</label>
            <button type="button" onclick="signTeacher()">_______________________________</button>
        </div>
    </div>
</section>
<BR> 
<br>

<script type="text/javascript">
        function redirectToPage() {
            window.location.href = "printback.php";
        }
    </script>

<section class="bottom-container">
<button type="submit" value="Save Record">SAVE RECORD</button>
<br>
<button type="button" onclick="history.back(); return false;">Previous Page</a></button> <br>
<button type="button" onclick="navigateToAnnexPage()">Next Page</button>
</section>
<button type="button" onclick="redirectToPage()"> VIEW SAVE RECORD </a>

    

</form>
    <script src="scripts.js"></script>
</body>
</html>


